import heapq

def dijkstra(graph, start):
    # Inisialisasi semua jarak lokasi dengan tak hingga (inf)
    distances = {node: float("inf") for node in graph}
    previous = {} # Untuk melacak rute jalan yang dilewati

    # Jarak ke titik mulai adalah 0
    distances[start] = 0
    pq = [(0, start)] # Priority Queue: (total_bobot, nama_node)

    while pq:
        current_distance, current_node = heapq.heappop(pq)

        # Jika menemukan bobot yang lebih besar dari yang sudah tercatat, lewati
        if current_distance > distances[current_node]:
            continue

        # Telusuri jalan/simpang yang terhubung dengan node saat ini
        for neighbor, weight in graph.get(current_node, {}).items():
            
            # Jika tetangga/simpang belum terdaftar di tabel jarak, buat default inf
            if neighbor not in distances:
                distances[neighbor] = float("inf")

            distance = current_distance + weight

            # Jika ditemukan jalur alternatif yang lebih cepat
            if distance < distances[neighbor]:
                distances[neighbor] = distance
                previous[neighbor] = current_node # Catat persimpangan sebelumnya
                
                heapq.heappush(
                    pq,
                    (distance, neighbor)
                )

    return distances, previous