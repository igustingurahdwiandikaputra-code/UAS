graph = {
    # ==========================
    # LAYANAN -> TITIK JEMPUT (Bobot: Prioritas/Ketersediaan Driver)
    # ==========================
    "GoRide": {
        "Stasiun_Tugu": 1,
        "Malioboro": 2,
        "Bandara_YIA": 5,
        "Terminal_Giwangan": 3
    },
    "GoCar": {
        "Stasiun_Tugu": 2,
        "Malioboro": 1,
        "Bandara_YIA": 3,
        "Terminal_Giwangan": 4
    },

    # ==========================
    # TITIK JEMPUT -> JALUR ANTARA (Bobot: Kepadatan Lalu Lintas)
    # ==========================
    "Stasiun_Tugu": {
        "Simpang_A": 2,
        "Simpang_B": 4
    },
    "Malioboro": {
        "Simpang_A": 1,
        "Simpang_C": 3
    },
    "Bandara_YIA": {
        "Tol_Barat": 5,
        "Jalur_Nasional": 8
    },
    "Terminal_Giwangan": {
        "Simpang_C": 4,
        "Ring_Road": 3
    },

    # ==========================
    # JALUR -> TITIK TUJUAN (Bobot: Jarak Akhir)
    # ==========================
    "Simpang_A": {
        "Kampus_UGM": 3,
        "RS_Sardjito": 2
    },
    "Simpang_B": {
        "Kampus_UGM": 5,
        "Kantor_Gubernur": 2
    },
    "Simpang_C": {
        "RS_Sardjito": 4,
        "Pasar_Bringharjo": 1
    },
    "Tol_Barat": {
        "Pusat_Kota": 10,
        "Kampus_UGM": 12
    },
    "Ring_Road": {
        "Kantor_Gubernur": 5,
        "RS_Sardjito": 6
    }
}