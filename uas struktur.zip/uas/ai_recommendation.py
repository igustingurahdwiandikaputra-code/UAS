def generate_ai_recommendation(service_type, pickup, best_destination):
    if service_type == "GoRide":
        return f"AI merekomendasikan rute ke {best_destination} via motor karena jalur ini terdeteksi padat; motor dapat bermanuver lebih cepat."
    
    elif "Tol" in pickup or "Bandara" in pickup:
        return f"Untuk perjalanan dari {pickup}, AI menyarankan penggunaan GoCar karena membawa bagasi dan melalui jalur cepat (Tol)."
    
    return f"Berdasarkan analisis Dijkstra, rute menuju {best_destination} adalah yang paling optimal dengan total hambatan terkecil."