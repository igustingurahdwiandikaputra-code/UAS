import streamlit as st
import networkx as nx
import matplotlib.pyplot as plt
import pandas as pd

from graph_data import graph
from dijkstra import dijkstra
from centrality import calculate_centrality
from ai_recommendation import generate_ai_recommendation

# ======================================
# PAGE CONFIG
# ======================================
st.set_page_config(page_title="Gojek Route DSS", page_icon="🚖", layout="wide")

if "service_types" not in st.session_state:
    st.session_state.service_types = ["GoRide", "GoCar"]

st.title("🚖 Gojek Smart Routing DSS")
st.subheader("Sistem Pendukung Keputusan Penentuan Rute Tercepat Menggunakan Graph & Dijkstra")
st.markdown("---")

# ======================================
# INPUT USER
# ======================================
col1, col2 = st.columns(2)
with col1:
    service = st.selectbox("Pilih Layanan Gojek", st.session_state.service_types)
with col2:
    pickup_point = st.selectbox("Pilih Titik Penjemputan", list(graph[service].keys()))

# ======================================
# ANALISIS
# ======================================
if st.button("🔍 Cari Rute Terbaik"):
    base_cost = graph[service][pickup_point]
    distances, previous = dijkstra(graph, pickup_point)
    
    # Mencari titik akhir (node yang tidak punya edge keluar lagi)
    destination_nodes = []
    for node in distances:
        if node not in graph or not graph[node]:
            destination_nodes.append(node)
            
    ranking = []
    for dest in destination_nodes:
        if distances[dest] != float("inf"):
            total_score = base_cost + distances[dest]
            ranking.append((dest, total_score))
    
    ranking.sort(key=lambda x: x[1])
    
    if ranking:
        best_dest = ranking[0][0]
        st.success(f"Rute optimal ditemukan menuju: {best_dest}")
        
        # Jalur Dijkstra
        path = []
        current = best_dest
        while current in previous:
            path.append(current)
            current = previous[current]
        path.append(pickup_point)
        path.reverse()
        
        final_path = [service] + path
        st.info("Jalur: " + " ➜ ".join(final_path))
        
        # AI Recommendation
        ai_msg = generate_ai_recommendation(service, pickup_point, best_dest)
        st.subheader("🤖 AI Smart Routing Advice")
        st.write(ai_msg)
        
        # Detail Perhitungan
        st.subheader("🧮 Logika Perhitungan Bobot (Waktu/Jarak)")
        df_calc = pd.DataFrame(ranking, columns=["Destinasi", "Total Bobot (Menit)"])
        st.table(df_calc)

# ======================================
# VISUALISASI GRAPH (Sama seperti kode skincare Anda)
# ======================================
st.markdown("---")
st.subheader("🌐 Visualisasi Jaringan Transportasi")
G = nx.DiGraph()
for source in graph:
    for target, weight in graph[source].items():
        G.add_edge(source, target, weight=weight)

fig, ax = plt.subplots(figsize=(15, 8))
pos = nx.spring_layout(G)
nx.draw(G, pos, with_labels=True, node_color="lightgreen", node_size=2500, font_size=10, arrows=True)
edge_labels = nx.get_edge_attributes(G, "weight")
nx.draw_networkx_edge_labels(G, pos, edge_labels=edge_labels)
st.pyplot(fig)