import networkx as nx

def calculate_centrality(graph):
    # Membuat objek Directed Graph baru khusus untuk perhitungan NetworkX
    G = nx.DiGraph()

    # Memasukkan semua data peta Gojek ke dalam objek NetworkX
    for source in graph:
        for target, weight in graph[source].items():
            G.add_edge(
                source,
                target,
                weight=weight
            )

    # Menghitung derajat kepentingan/pusat keramaian tiap lokasi
    return nx.degree_centrality(G)